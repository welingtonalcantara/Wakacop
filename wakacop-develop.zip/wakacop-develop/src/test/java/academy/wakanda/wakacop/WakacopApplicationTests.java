package academy.wakanda.wakacop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WakacopApplicationTests {

	@Test
	void contextLoads() {
	}

}
